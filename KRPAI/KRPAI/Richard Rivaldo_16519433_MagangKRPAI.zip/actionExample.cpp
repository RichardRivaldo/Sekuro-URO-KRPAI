#include "Aria.h"
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <fstream>
#include <time.h>
using namespace std;

const int SONAR_NUM = 16;
const int WALL_DIST = 3;
const int LINEAR_SPEED = 300;
const int SIDEWAY_WALK_ROTATION = 4;
const int ROTATE_SPEED = 55;

int jarak[SONAR_NUM];
int v = LINEAR_SPEED;
int w = 0;

typedef enum { 
  northwest = 0,
  north = 1,
  northeast = 2,
  east = 4,
  south = 5,
  west = 3
} direction;

typedef enum {
  kiri, 
  kanan
} wallDirection;

typedef enum {
  CW,
  CCW
} orientation;

int getSonar(int dir) {
  int distance;
  switch (dir) {
    case north:
      distance = min(jarak[3],jarak[4]);
      break;
    case east:
      distance = min(jarak[7], jarak[8]);
      break;
    case south:
      distance = min(jarak[11], jarak[12]);
      break;
    case west:
      distance = min(jarak[0], jarak[15]);
      break;
    case 11: // east front
      distance = jarak[7];
      break;
    case 12: // east rear
      distance = jarak[8];
      break;
    case 21: // west front
      distance = jarak[0];
      break;
    case 22: // west rear
      distance = jarak[15];
  }
  return distance;
}

void updateSonar(ArRobot *thisRobot) {
  ArSensorReading* sonarReading; // To hold each reading

  // Loop through sonar
  for (int i = 0; i < SONAR_NUM; i++) {
    sonarReading = thisRobot->getSonarReading(i);
    jarak[i] = (sonarReading->getRange())*0.01;
  }
}


bool isWall(ArRobot *thisRobot, direction dir) {
  updateSonar(thisRobot);
  return getSonar(dir) < WALL_DIST;
}

void moveForward(ArRobot *robot){
  v = LINEAR_SPEED;
  w = 0;
  int kiriAtas = getSonar(21);
  int kiriBawah = getSonar(22);
  bool kiriValid = max(kiriAtas, kiriBawah) < 20;

  int kananAtas = getSonar(11);
  int kananBawah = getSonar(12);
  bool kananValid = max(kananAtas, kananBawah) < 20;

  if (((kiriAtas > kiriBawah) && kiriValid) || ((kananAtas < kananBawah) && kananValid)){
	  w = SIDEWAY_WALK_ROTATION;
  } else if (((kiriAtas < kiriBawah) && kiriValid) || ((kananAtas > kananBawah) && kananValid)) {
	  w = -1 * SIDEWAY_WALK_ROTATION;
  } else {
	  w = 0;
  }
  robot->setVel(v);
  robot->setRotVel(w);
}

void stop(ArRobot *robot){
  v = 0;
  w = 0;
  robot->setVel(v);
  robot->setRotVel(w);
}

void rotate(ArRobot *robot, orientation ori, float degree) {
  switch (ori) {
    case CCW :
      v = 0;
      w = ROTATE_SPEED;
      robot->setVel(v);
      robot->setRotVel(w);
      break;
    case CW :
      v = 0;
      w = -1 * ROTATE_SPEED;
      robot->setVel(v);
      robot->setRotVel(w);
      break;
    default : 
      break;
  }
  while (isWall(robot, north)){
	Sleep(0.1);
  }
  stop(robot);
}

wallDirection temp;
wallDirection dir_Min;
wallDirection dir_Max;

wallDirection FindMin (){
	if (min(jarak[0], jarak[15]) < min(jarak[7], jarak[8]))
		dir_Min = kiri;
	else
		dir_Min = kanan;
	return dir_Min;
}

wallDirection FindMax (){
	if (min(jarak[0], jarak[15]) > min(jarak[7], jarak[8]))
		dir_Max= kiri;
	else
		dir_Max= kanan;
	return dir_Max;
}

void Example(ArRobot *robot, wallDirection dir){
	while (!isWall(robot, north)) {
		moveForward(robot);
		if (min(jarak[0], jarak[15]) < (min(jarak[7], jarak[8]) && isWall(robot, north) && isWall(robot, northeast)))
			dir = kiri;
		else
			dir = kanan; 
		if (dir == kiri)
			rotate(robot, CCW, 90);
		else
			rotate(robot, CW, 90);
		moveForward(robot);
		if (isWall(robot, north))
			cout << "Ada dinding di depan" << endl;
	}
}
int main(int argc, char **argv) {
  Aria::init();
  ArRobot robot;
  ArSonarDevice sonar;
  robot.addRangeDevice(&sonar);
  ArArgumentParser parser(&argc, argv);
  ArSimpleConnector connector(&parser);
  parser.loadDefaultArguments();
  if (!connector.parseArgs()) {
    cout << "Unknown settings\n";
    Aria::exit(0);
    exit(1);
  }

  if (!connector.connectRobot(&robot)) {
    cout << "Unable to connect\n";
    Aria::exit(0);
    exit(1);
  }

  robot.runAsync(true);
  robot.lock();
  robot.comInt(ArCommands::ENABLE, 1);
  robot.unlock();

  robot.setVel(v);
  robot.setRotVel(w);
  
  while (true) {
    Example(&robot, kiri);
  }

  return 0;
}